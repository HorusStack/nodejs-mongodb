const fs = require('fs')
const jwt = require('jsonwebtoken');
const UserModel = require('../models/user');
const { signUpValidator } = require('./validators');
const Login = async(req,resp)=>{
    const User = await UserModel.find({$text: {$search: 'rahul'}});
    resp.status(200).send(User);
    
}
module.exports={Login}