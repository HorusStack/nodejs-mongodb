const fs = require('fs');
const jwt = require('jsonwebtoken');
const { resolve } = require('path');
const UserModel = require('../models/user');
const { signUpValidator } = require('./validators');
const Signup = async(req,resp)=>{
    try{

        const {name, password} = req.body;
        const addeduser = await UserModel.create({username:name,password:password})
       console.log(addeduser)
        resp.status(200).json({message:addeduser});
    }catch(err){
        console.log(err)
    }
}
module.exports={Signup}
