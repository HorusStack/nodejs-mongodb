const UserModel = require("../../models/user");
const GetUsers = async(req,resp)=>{

    try{
        const {offset=10,pageno=1} = req.body;
        const users=await UserModel.find({}).limit(offset).skip((pageno-1)*offset);
        resp.status(200).json({users:users});

    }catch(err){
        console.log(err)
        resp.status(400).json({msg:"something went wrong"});
    }

}
module.exports={GetUsers}