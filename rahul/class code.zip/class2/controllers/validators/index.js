var validate = require('jsonschema').validate

const signUpValidator = (req)=>{

    return validate(req,{
        "additionalProperties":false,
        "type":"object",
        "properties":{
            "name":{"type":"string","required":true},
            "password":{"type":"string","required":true}
        }
    })

}

module.exports={signUpValidator};