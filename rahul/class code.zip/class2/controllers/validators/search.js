const UserModel = require("../../models/user");

const Search = async(req,resp)=>{
    try{
        const {searchtag,offset,pageno} = req.body;
        const results = await UserModel.find({$text :{$search: searchtag}}).limit(offset).skip((pageno-1)*offset);
        resp.status(200).json({results:results});
    }catch(err){
        console.log(err);
        resp.status(400).json({message:err.message})
    }
}
module.exports={Search};