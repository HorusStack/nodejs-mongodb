const express = require('express');
const { Login } = require('../controllers/loginController');
const { Signup } = require('../controllers/signupController');
const { GetUsers } = require('../controllers/validators/getUsers');
const { Search } = require('../controllers/validators/search');
const router = express.Router();

router.get('/',(req,resp)=>{
    resp.status(200).json({'message':'success'});
})
router.post('/signup',Signup)
router.post('/getusers',GetUsers)
router.post('/search',Search);
router.post('/login',Login)//localhost:9000/login https://domainname.com/login
module.exports = router;