const mongoose = require('mongoose');
const express = require('express');
const router = require('./routes/router')
const app  = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(router);
mongoose.connect('mongodb+srv://Admin:Rahul123@cluster0.b40wo.mongodb.net/Test?retryWrites=true&w=majority',{useNewUrlParser:true,useUnifiedTopology:true,useCreateIndex:true},(err)=>{
    if(!err){
        app.listen(8080,(err)=>{
            if(!err){
                console.log('connected');
            }
            else{
                console.log(err)
            }
        })
    }
    else{
        console.log(err)
    }
})