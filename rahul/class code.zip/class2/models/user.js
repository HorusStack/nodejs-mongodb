const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username:{type:String, required:true, unique:true},
    password:{type:String},
    time:{type:String,default:new Date().toLocaleString('en-uk')}
})
UserSchema.index({'$**': 'text'});
const UserModel = mongoose.model('Users',UserSchema);
module.exports = UserModel;