const fs = require('fs');
const jwt = require('jsonwebtoken');
const { signUpValidator } = require('./validators');
const Signup = async(req,resp)=>{
    const token = req.headers['authorization'];
    console.log(token);
    jwt.verify(token,'12345678',(err,data)=>{
        if(err){
            console.log(err);
            resp.status(400).send('Login again');
        }
        else{
            resp.status(200).send('Success');
            console.log(data)
        }
    })
}
module.exports={Signup}
