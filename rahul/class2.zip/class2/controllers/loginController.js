const fs = require('fs')
const jwt = require('jsonwebtoken');
const Login = async(req,resp)=>{
    const {name,password} = req.body;
    const data = fs.readFileSync('user.txt','utf-8');
    const details = data.split(',')
    if(name===details[0]){
        if(password===details[1]){
           const token =  jwt.sign({name,password},'12345678',{expiresIn:'120s'})
           console.log(token);
            return resp.status(200).json({'message':'Login successful'});
        }
        else{
            return resp.status(400).json({'message':'Password didnot match'})
        }
    }
    else{
        return resp.status(404).json({'message':'User not found'});
    }
}
module.exports={Login}