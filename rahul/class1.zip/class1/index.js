var http = require('http');
var url = require('url');
var fs = require('fs');

fs.writeFile('test','Rahul,Harshith',(err)=>{
if(err){
    console.log(err)
}
console.log('File created successfully');
})

http.createServer((req,resp)=>{
//successful
const data = fs.readFileSync('test','utf8');
const names = data.split(',');
const q = url.parse(req.url,true).query

resp.writeHead(200,{
    'Content-Type':'text/html'
})
console.log(names);
console.log(q.name);
if(names.includes(q.name)){
     resp.write('Login Successful '+q.name);
     return resp.end('Thank you')
}
else{
     resp.write('Login failed '+q.name);
    return resp.end('Thank you')
}


},(err)=>{
    //failure
    console.log(err)
}).listen(8080,()=>{
    //failure
    console.log('Server started listening at port 8080')
})