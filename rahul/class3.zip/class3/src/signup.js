import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function SignUp(props) {
  const [name, setName] = useState("");
  const [password,setPassword]=useState("");
  const submit=()=>{
    fetch("http://localhost:9000/signup",{
      method:'POST',
      headers:{
        'Content-Type':'application/json'
      },
      body:JSON.stringify({
        name:name,
        password:password,
      })
    }).then((res)=>{
        return res.json()
    }).then((data)=>{
      console.log(data);
      props.history.push('/login')
    })
  }

  return (
    <div >
      <h2 style={{textAlign:'center'}}>Sign up Page</h2>
    <div style={{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",height:"30vh"}}>
      <input placeholder={'Name'} value={name} onChange={(e)=>{setName(e.target.value)}} style={{width:'50%',height:3+'em'}}></input>
      <input type={"password"} placeholder={'Password'} value={password} onChange={(e)=>{setPassword(e.target.value)}} style={{width:'50%',height:3+'em',marginTop:10}}></input>
      <button onClick={()=>{submit()}} style={{backgroundColor:'green',fontFamily:'serif',fontWeight:'bold',color:'white',height:3+'em',marginTop:10}}>Submit</button>
    </div>
    </div>
  );
}

export default SignUp;
