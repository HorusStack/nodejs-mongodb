import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function Login(props) {
  const [name, setName] = useState("");
  const [password,setPassword]=useState("");
  const [message, setMessage] = useState("");
  const submit=()=>{
    fetch("http://localhost:9000/login",{
      method:'POST',
      headers:{
        'Content-Type':'application/json'
      },
      body:JSON.stringify({
        name:name,
        password:password,
      })
    }).then((res)=>{
        return res.json()
    }).then((data)=>{
      console.log(data);
      setMessage(data.message)
      localStorage.setItem('token',data.token);
    })
  }

  return (
    <div >
      <h2 style={{textAlign:'center'}}>Login Page</h2>
    <div style={{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",height:"30vh"}}>
      <input placeholder={'Name'} value={name} onChange={(e)=>{setName(e.target.value)}} style={{width:'50%',height:3+'em'}}></input>
      <input  type={"password"}  placeholder={'Password'} value={password} onChange={(e)=>{setPassword(e.target.value)}} style={{width:'50%',height:3+'em',marginTop:10}}></input>
      <button onClick={()=>{submit()}} style={{backgroundColor:'green',fontFamily:'serif',fontWeight:'bold',color:'white',height:3+'em',marginTop:10}}>Submit</button>
  <h2 style={{marginTop:10}}>{message}</h2>
    </div>
    </div>
  );
}

export default Login;
