import React from 'react'
import {Switch, Route, Redirect, BrowserRouter} from 'react-router-dom'
import Login from './login'
import SignUp from './signup'
function App() {
  return (
      <BrowserRouter>
      <Switch>
        <Route path="/signup" exact component={SignUp}>
          </Route> 
          <Route path="/login" exact component={Login}>
          </Route>      
          <Redirect from="*" to="/signup"/>  
       </Switch>
          </BrowserRouter>
  )
}

export default App
